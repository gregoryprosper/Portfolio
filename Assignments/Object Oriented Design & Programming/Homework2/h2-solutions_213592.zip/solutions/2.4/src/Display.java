// H2 - 2.5

import java.io.PrintStream;
import java.io.IOException;


/**
   Display line items, receipt and total price.
*/
class Display {
    /**
       constructor.
       @param writer stream used to output text
    */
    public Display(PrintStream stream) {
	this.stream = stream;
    }

    /**
       display text
    */
    public void display(String text) {
	this.stream.println(text);
    }

    private PrintStream stream;
}

