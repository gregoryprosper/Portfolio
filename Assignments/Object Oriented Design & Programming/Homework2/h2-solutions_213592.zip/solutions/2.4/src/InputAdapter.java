// H2 - 2.4

import java.io.InputStream;

/**
   this object simulates scanner and CR KBD input using an input stream, such as System.in
*/
public class InputAdapter {
    /**
       constructor. Creates a Scanner from the reference to data input stream.
       @param input stream
       @param scanner the UpcScanner
       @param kbd the cash register keyboard
    */
    public InputAdapter(InputStream is, UpcScanner sc, CashRegKbd kbd) {
	this.scanner = sc;
	this.kbd = kbd;
	this.insc = new java.util.Scanner(is);
    }


    /**
       waits for user input. Translates this input for the scanner and the keyboard.
       This method ends when user types "quit".
    */
    public void eventLoop() {
	boolean done = false;

	System.out.println("Enter UPC, or 'p' - pay, 'c' - complete, or quit");
	while (! done && this.insc.hasNext()) {
	    String s = insc.next();

	    if (s.equalsIgnoreCase("quit")) {
		done = true;
	    }
	    else if (s.equalsIgnoreCase("p")) {
		this.kbd.payClicked();
	    }
	    else if (s.equalsIgnoreCase("c")) {
		this.kbd.completeClicked();
	    }
	    else {
		this.scanner.upcScanned(s);
	    }
	}

	if (! done) {
	    System.out.println("Enter UPC, or 'p' - pay, 'c' - complete, or quit");
	}
    }

    private UpcScanner scanner;
    private CashRegKbd kbd;

    private java.util.Scanner insc;
}