// H2 - 2.5
import java.util.*;

/**
   maintains the list of items for the current purchase
*/
public class ItemList {
    /**
       constructor. Creates product list
    */
    public ItemList() {
	this.list = new LinkedList<Product>();
    }

    /**
       adds new item
       @param p the product
    */
    public void addProduct(Product p) {
	this.list.add(p);
    }

    /**
       clears the items list
    */
    public void clear() {
	this.list.clear();
    }

    /**
       returns a string representation of the item list
    */
    public String toString() {
	StringBuffer sb = new StringBuffer();
	sb.append("Item count: " + this.list.size() + "\n\n");

	// append the text for all products:
	for (Product p: this.list) {
	    sb.append(p.toString());
	    sb.append("\n");
	}

	return sb.toString();
    }

    /**
       product list
    */
    private List <Product> list;
}
