// H2 - 2.5

/**
   Product.
*/
public class Product {
    /** 
	Constructor 
	@param price
	@param count # of items of this product type remaining in the inventory
	@param name product name
	@param upc the UPC
    */
    public Product(double price, int count, String name, String upc) {
	this.price = price;
	this.count = count;
	this.name = name;
	this.upc = upc;
    }

    /**
       @return a formatted textual representation of this product
    */
    public String toString() {
	return this.name + ", upc: " + this.upc + ", c: " + count + ", $" + this.price;
    }

    /** 
	price accessor.
	@return price
    */
    public double getPrice() {
	return this.price;
    }

    /**
       @return the UPC
    */
    public String getUpc() {
	return this.upc;
    }

    private double price;

    private String upc;

    private String name;

    private int count;
};
