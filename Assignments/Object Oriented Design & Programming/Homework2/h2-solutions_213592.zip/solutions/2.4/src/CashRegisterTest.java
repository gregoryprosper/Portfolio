// H2 - 2.5

/**
   assemble a cash register and all components.
*/
public class CashRegisterTest {
    public static void main(String[] args) {
	Display display = new Display(System.out);

	Inventory inv = new Inventory();

	CashRegister cr = new CashRegister(inv, display);

	UpcScanner scanner = new UpcScanner(cr);

	CashRegKbd kbd = new CashRegKbd(cr);

	InputAdapter input = new InputAdapter(System.in, scanner, kbd);

	// add some products to the inventory:
	inv.add(new Product(1.20, 100, "Toblerone", "1"));
	inv.add(new Product(2.70, 100, "Milka", "2"));
	inv.add(new Product(0.50, 1000, "Snickers", "3"));
	inv.add(new Product(1.24, 100, "Lindt", "4"));

	// start the input loop.
	input.eventLoop();
    }
}