// H2 - 2.5


/**
   this class simulates a UPC scanner.
*/
public class UpcScanner {
    /**
       constructor. saves a reference to the CashRegister object
       @param cr the cash register
    */
    public UpcScanner(CashRegister cr) {
	this.cashRegister = cr;
    }

    /**
       product UPC was scanned.
       @param the product UPC
    */
    public void upcScanned(String upc) {
	this.cashRegister.scanEvent(upc);
    }

    private CashRegister cashRegister;
};
