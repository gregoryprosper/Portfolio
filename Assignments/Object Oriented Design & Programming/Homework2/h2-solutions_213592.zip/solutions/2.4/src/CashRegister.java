// H2 - 2.5
import java.io.IOException;


/**
   the cash register class.
*/
public class CashRegister {
    /**
       cash register states
    */
    private enum CRState { SCANNING, WAITING_PAYMENT};


    /**
       creates a cashregister object
    */
    public CashRegister(Inventory inv, Display display) {
	this.inv = inv;
	this.display = display;

	this.itemList = new ItemList();

	this.total = 0;
	this.state = CRState.SCANNING;
    }


    /**
       UPC was scanned.
       @param upc the UPC
    */
    public void scanEvent(String upc) {
	switch (this.state) {
	case SCANNING:
	    try {
		Product p = this.inv.lookupProduct(upc);

		this.itemList.addProduct(p);

		this.display.display(p.toString());

		// update purchase total:
		total += p.getPrice();

	    } catch (IllegalArgumentException ex) {
		this.display.display("Wrong UPC: " + upc);
	    }
	    break;
	    
	    // if scan event while not in the scanning state, ignore event
	default:
	    this.display.display("Ignore scan");
	}
    }


    /**
       pay event. Cashier has pressed on the "pay" button.
    */
    public void payEvent() {
	switch (this.state) {
	case SCANNING:
	    this.display.display(this.itemList.toString());
	    this.display.display("Total is " + this.total);

	    // transition to state WAITING_PAYMENT
	    this.state = CRState.WAITING_PAYMENT;
	    break;
	    
	    // if scan event while not in the scanning state, ignore event
	default:
	    this.display.display("Ignore pay event\n");
	}
    }


    /**
       complete event. Cashier has pressed on the "complete" button.
    */
    public void completeEvent() {
	switch (this.state) {
	case WAITING_PAYMENT:
	    // complete purchase. Client has finished paying.
	    this.reset();

	    this.state = CRState.SCANNING;

	    this.display.display("Purchase completed.\n\n");
	    break;
	    
	    // if scan event while not in the scanning state, ignore event
	default:
	    this.display.display("Ignore 'complete' event\n");
	}
    }


    /**
       reset purchase. Prepare CR for next customer.
    */
    private void reset() {
	this.itemList.clear();
	this.total = 0;
    }


    private Display display;
    private Inventory inv;

    /**
       purchase total
    */
    private double total;

    /**
       cash register state
    */
    private CRState state;

    private ItemList itemList;
};
