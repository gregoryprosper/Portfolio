// H2 - 2.5
import java.util.HashMap;

/**
   provides a product lookup service from the  product inventory.
*/
public class Inventory {
    /**
       constructor. Creates product list (- actually a map, indexed by UPC)
    */
    public Inventory() {
	this.prodmap = new HashMap<String, Product>();
    }

    /**
       search product in inventory.
       @param upc the product UPC
       @throws IllegalArgumentException if invalid UPC (product not found)
    */
    public Product lookupProduct(String upc) throws IllegalArgumentException {
	Product p = this.prodmap.get(upc);

	if (p == null) {
	    throw new IllegalArgumentException("Invalid UPC " + upc);
	}
	return p;
    }


    /**
       adds a product to the inventory. Only products with unique UPCs are stored.
       @param p the product
    */
    public void add(Product p) {
	this.prodmap.put(p.getUpc(), p);
    }

    /**
       product map indexed by UPC string.
    */
    private HashMap<String, Product> prodmap;
}
