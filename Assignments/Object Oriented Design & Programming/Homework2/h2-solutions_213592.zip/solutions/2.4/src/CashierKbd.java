// H2 - 2.5


/**
   simulates the keyboard on the cash register 
*/
public class CashRegKbd {
    /**
       constructor.
    */
    public CashRegKbd(CashRegister cr) {
	this.cashRegister = cr;
    }

    /**
       invoked when cashier pressed on the "Pay" button
    */
    public payClicked() {
	this.cashRegister.payEvent();
    }

    /**
       invoked when cashier pressed on the "Complete" button
    */
    public completeClicked() {
	this.cashRegister.completeEvent();
    }
};
